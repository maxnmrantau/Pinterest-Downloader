// Service worker: memeriksa kandidat URL lalu memulai unduhan lewat chrome.downloads.

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'PDL_DOWNLOAD') {
    handleDownload(msg)
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, error: String((err && err.message) || err) }));
    return true; // respons asinkron
  }
});

async function pickReachable(candidates) {
  for (const url of candidates) {
    try {
      const res = await fetch(url, { method: 'HEAD' });
      if (res.ok) return url;
    } catch (_) {
      // coba kandidat berikutnya
    }
  }
  return null;
}

function filenameFor(url, kind, id) {
  let base = 'pinterest';
  try {
    base = decodeURIComponent(new URL(url).pathname.split('/').pop() || base);
  } catch (_) {}
  base = base.replace(/[^\w.\-]+/g, '_');
  if (!/\.[a-z0-9]{2,5}$/i.test(base)) base += kind === 'video' ? '.mp4' : '.jpg';
  return `Pinterest/${id ? id + '_' : ''}${base}`;
}

async function handleDownload({ kind, candidates, id }) {
  if (!Array.isArray(candidates) || !candidates.length) {
    return { ok: false, error: 'URL media tidak ditemukan' };
  }
  const url = await pickReachable(candidates);
  if (!url) return { ok: false, error: 'Tidak ada URL yang bisa diunduh' };

  const downloadId = await chrome.downloads.download({
    url,
    filename: filenameFor(url, kind, id),
    conflictAction: 'uniquify',
    saveAs: false
  });
  return { ok: true, downloadId, url };
}
