(() => {
  'use strict';
  if (window.__pdlLoaded) return;
  window.__pdlLoaded = true;

  const VERSION = '1.3.0';
  const MIN_SIZE = 140; // abaikan avatar/ikon kecil
  console.log('[PinDL] v' + VERSION + ' aktif');

  const svg = (inner, extra = '') =>
    `<svg ${extra} viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;
  const ICONS = {
    download: svg('<path d="M12 3v12"/><path d="m7 11 5 5 5-5"/><path d="M5 20h14"/>'),
    check: svg('<path d="m5 12.5 4.5 4.5L19 7.5"/>'),
    error: svg('<path d="M12 7v6"/><path d="M12 17h.01"/>'),
    spinner: svg('<path d="M12 3a9 9 0 1 0 9 9"/>', 'class="pdl-spin"')
  };

  const unique = (arr) => [...new Set(arr.filter(Boolean))];

  // ---------- Toast ----------
  let toastEl = null;
  let toastTimer = null;
  function toast(msg, isError) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'pdl-toast';
      document.documentElement.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.classList.toggle('pdl-toast-error', !!isError);
    toastEl.classList.add('pdl-toast-show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('pdl-toast-show'), 2600);
  }

  // ---------- Util DOM ----------
  function findHost(media) {
    return (
      media.closest(
        '[data-test-id="pin"], [data-test-id="pinWrapper"], [data-test-id="pin-visual-wrapper"], [data-grid-item="true"]'
      ) || media.parentElement
    );
  }

  function getPinId(media) {
    const re = /\/pin\/(?:[^/]*-)?(\d+)/;
    const loc = location.pathname.match(re);
    if (loc && media.getBoundingClientRect().width >= 380) return loc[1]; // tampilan besar = pin yang sedang dibuka
    let el = media;
    for (let i = 0; el && i < 12; i++, el = el.parentElement) {
      const links = [];
      if (el.matches && el.matches('a[href*="/pin/"]')) links.push(el);
      if (el.querySelectorAll) links.push(...el.querySelectorAll('a[href*="/pin/"]'));
      const ids = new Set();
      for (const a of links) {
        const m = (a.getAttribute('href') || '').match(re);
        if (m) ids.add(m[1]);
      }
      if (ids.size === 1) return [...ids][0]; // hanya jika ambigu-nya tidak ada
      if (ids.size > 1) break; // sudah mencakup banyak pin
    }
    const m = location.pathname.match(re);
    return m ? m[1] : null;
  }

  // ---------- Resolusi URL gambar ----------
  function imageCandidates(img) {
    const src = img.currentSrc || img.src || '';
    const list = [];
    const toOrig = (u) => u.replace(/(pinimg\.com)\/(?!originals\/)[^/]+\//, '$1/originals/');
    const withExt = (u, ext) => u.replace(/\.[a-z0-9]+(\?.*)?$/i, '.' + ext);

    const orig = toOrig(src);
    list.push(orig);
    ['png', 'jpg', 'gif', 'webp'].forEach((ext) => list.push(withExt(orig, ext)));
    list.push(src.replace(/(pinimg\.com)\/[^/]+\//, '$1/1200x/'));
    list.push(src.replace(/(pinimg\.com)\/[^/]+\//, '$1/736x/'));

    if (img.srcset) {
      const urls = img.srcset.split(',').map((s) => s.trim().split(/\s+/)[0]);
      if (urls.length) list.push(urls[urls.length - 1]);
    }
    list.push(src);
    return unique(list);
  }

  // ---------- Resolusi URL video ----------
  const jsonCache = new Map();
  const FIELD_SETS = ['detailed', 'unauth_react_main_pin'];

  async function fetchPinJson(id, fieldSet) {
    const key = id + ':' + fieldSet;
    if (jsonCache.has(key)) return jsonCache.get(key);
    const data = { options: { id, field_set_key: fieldSet, noCache: true, add_vase: true }, context: {} };
    const url =
      `${location.origin}/resource/PinResource/get/?source_url=${encodeURIComponent('/pin/' + id + '/')}` +
      `&data=${encodeURIComponent(JSON.stringify(data))}`;
    const res = await fetch(url, {
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json, text/javascript, */*, q=0.01',
        'X-Requested-With': 'XMLHttpRequest',
        'X-Pinterest-AppState': 'active'
      }
    });
    if (!res.ok) throw new Error('API ' + res.status);
    const json = await res.json();
    jsonCache.set(key, json);
    return json;
  }

  function collectVideos(obj, out = []) {
    if (!obj || typeof obj !== 'object') return out;
    if (obj.video_list && typeof obj.video_list === 'object') {
      for (const v of Object.values(obj.video_list)) if (v && v.url) out.push(v);
    }
    for (const k in obj) if (obj[k] && typeof obj[k] === 'object') collectVideos(obj[k], out);
    return out;
  }

  // Tebakan URL mp4 dari URL HLS (nanti dicek satu-satu oleh background)
  function guessMp4FromHls(list) {
    const out = [];
    for (const u of list) {
      const m = u.match(/^(.*?\/videos\/[^/]+)\/hls\/(.+?)\.m3u8/);
      if (!m) continue;
      const prefix = m[1];
      const rest = m[2];
      const noSuffix = rest.replace(/_\d+w$/, '');
      out.push(
        `${prefix}/720p/${rest}.mp4`,
        `${prefix}/720p/${noSuffix}.mp4`,
        `${prefix}/expMp4/${rest}.mp4`,
        `${prefix}/expMp4/${noSuffix}_720w.mp4`
      );
    }
    return unique(out);
  }

  function videosFromJson(json) {
    const all = collectVideos(json);
    const mp4 = all
      .filter((v) => /\.mp4(\?|$)/i.test(v.url))
      .sort((a, b) => (b.width * b.height || 0) - (a.width * a.height || 0))
      .map((v) => v.url);
    const hls = all.filter((v) => /\.m3u8/i.test(v.url)).map((v) => v.url);
    return { mp4: unique(mp4), hls: unique(hls) };
  }

  async function scrapeVideosFromHtml(id) {
    const res = await fetch(`${location.origin}/pin/${id}/`, { credentials: 'same-origin' });
    if (!res.ok) throw new Error('HTML ' + res.status);
    const html = (await res.text()).replace(/\\u002F/gi, '/').replace(/\\\//g, '/');
    const mp4 = [...html.matchAll(/https:\/\/v\d*\.pinimg\.com\/videos\/[^"'\s\\<>]+?\.mp4/g)].map((m) => m[0]);
    const hls = [...html.matchAll(/https:\/\/v\d*\.pinimg\.com\/videos\/[^"'\s\\<>]+?\.m3u8/g)].map((m) => m[0]);
    const score = (u) => (/720p|expMp4|1080p/.test(u) ? 0 : 1);
    return { mp4: unique(mp4.sort((a, b) => score(a) - score(b))), hls: unique(hls) };
  }

  // URL video yang sedang/baru dimuat oleh player Pinterest (terbaru dulu)
  function streamsFromPerformance() {
    const names = performance
      .getEntriesByType('resource')
      .map((e) => e.name)
      .filter((n) => /pinimg\.com\/videos\//.test(n))
      .reverse();
    return {
      mp4: unique(names.filter((n) => /\.mp4(\?|$)/i.test(n))),
      hls: unique(names.filter((n) => /\.m3u8/i.test(n)))
    };
  }

  // ---------- Unduh HLS langsung di browser (gabung segmen) ----------
  const absUrl = (base, ref) => new URL(ref, base).href;

  async function fetchText(u) {
    const r = await fetch(u);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  }
  async function fetchBuf(u) {
    const r = await fetch(u);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.arrayBuffer();
  }

  function saveBlob(blob, name) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.style.display = 'none';
    document.documentElement.appendChild(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(a.href);
      a.remove();
    }, 15000);
  }

  async function downloadHlsOne(url, id) {
    let base = url;
    let text = await fetchText(url);

    if (/#EXT-X-STREAM-INF/.test(text)) {
      const lines = text.split(/\r?\n/);
      let best = null;
      let bw = -1;
      for (let i = 0; i < lines.length; i++) {
        if (!lines[i].startsWith('#EXT-X-STREAM-INF')) continue;
        const m = lines[i].match(/BANDWIDTH=(\d+)/);
        const b = m ? +m[1] : 0;
        let k = i + 1;
        while (k < lines.length && (!lines[k] || lines[k].startsWith('#'))) k++;
        if (lines[k] && b > bw) {
          bw = b;
          best = lines[k];
        }
      }
      if (!best) throw new Error('Variant HLS tidak ditemukan');
      base = absUrl(url, best);
      text = await fetchText(base);
    }

    if (/#EXT-X-KEY:METHOD=(?!NONE)/.test(text)) throw new Error('Video HLS terenkripsi');

    const segs = text
      .split(/\r?\n/)
      .filter((l) => l && !l.startsWith('#'))
      .map((l) => absUrl(base, l));
    if (!segs.length) throw new Error('Segmen HLS kosong');

    const buffers = [];
    const map = text.match(/#EXT-X-MAP:URI="([^"]+)"/);
    if (map) buffers.push(await fetchBuf(absUrl(base, map[1])));

    const BATCH = 6;
    for (let i = 0; i < segs.length; i += BATCH) {
      const part = await Promise.all(segs.slice(i, i + BATCH).map(fetchBuf));
      buffers.push(...part);
      toast(`Mengunduh video… ${Math.min(i + BATCH, segs.length)}/${segs.length}`);
    }

    const isMp4 = !!map || /\.(m4s|mp4|cmfv)(\?|$)/i.test(segs[0]);
    const ext = isMp4 ? 'mp4' : 'ts';
    const blob = new Blob(buffers, { type: isMp4 ? 'video/mp4' : 'video/mp2t' });
    saveBlob(blob, `Pinterest_${id || Date.now()}.${ext}`);
  }

  async function downloadHls(urls, id) {
    let lastErr = null;
    for (const u of urls) {
      try {
        return await downloadHlsOne(u, id);
      } catch (e) {
        console.warn('[PinDL] HLS gagal:', u, e);
        lastErr = e;
      }
    }
    throw lastErr || new Error('HLS gagal diunduh');
  }

  // ---------- Tentukan media yang akan diunduh ----------
  async function resolveMedia(media) {
    const id = getPinId(media);
    const isVideoEl = media.tagName === 'VIDEO';
    const host = findHost(media);
    const hint = isVideoEl || !!(host && host.querySelector('video'));
    const dbg = { id, api: [], scrape: null, perf: null };

    let streams = { mp4: [], hls: [] };
    const has = () => streams.mp4.length || streams.hls.length;

    if (id) {
      const keys = hint ? FIELD_SETS : FIELD_SETS.slice(0, 1);
      for (const key of keys) {
        try {
          const found = videosFromJson(await fetchPinJson(id, key));
          dbg.api.push(`${key}: mp4=${found.mp4.length} hls=${found.hls.length}`);
          if (found.mp4.length || found.hls.length) {
            streams = found;
            break;
          }
        } catch (e) {
          dbg.api.push(`${key}: ${(e && e.message) || e}`);
        }
      }
      if (!has() && hint) {
        try {
          streams = await scrapeVideosFromHtml(id);
          dbg.scrape = `mp4=${streams.mp4.length} hls=${streams.hls.length}`;
        } catch (e) {
          dbg.scrape = (e && e.message) || String(e);
        }
      }
    }

    if (isVideoEl && !has()) {
      const s = media.currentSrc || media.src || '';
      if (/^https?:/.test(s) && /\.mp4/i.test(s)) streams.mp4.push(s);
      if (!has()) {
        streams = streamsFromPerformance();
        dbg.perf = `mp4=${streams.mp4.length} hls=${streams.hls.length}`;
      }
    }

    if (has()) {
      return {
        kind: 'video',
        candidates: unique([...streams.mp4, ...guessMp4FromHls(streams.hls)]),
        hls: streams.hls,
        id
      };
    }
    if (isVideoEl) {
      console.warn('[PinDL] video tidak ditemukan. Debug:', dbg);
      throw new Error('URL video tidak ditemukan (detail ada di Console)');
    }
    return { kind: 'image', candidates: imageCandidates(media), hls: [], id };
  }

  // ---------- Tombol melayang ----------
  const CARD_SEL =
    '[data-test-id="pin"], [data-test-id="pinWrapper"], [data-test-id="pin-visual-wrapper"], [data-grid-item="true"]';

  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'pdl-btn pdl-hidden';
  document.documentElement.appendChild(btn);

  let current = null; // media yang sedang di-hover
  let lock = false; // true saat proses unduh berjalan
  let lastX = -1;
  let lastY = -1;
  let ticking = false;

  function setState(state) {
    btn.classList.remove('pdl-busy', 'pdl-done', 'pdl-error');
    if (state === 'busy') {
      btn.classList.add('pdl-busy');
      btn.innerHTML = ICONS.spinner;
    } else if (state === 'done') {
      btn.classList.add('pdl-done');
      btn.innerHTML = ICONS.check;
    } else if (state === 'error') {
      btn.classList.add('pdl-error');
      btn.innerHTML = ICONS.error;
    } else {
      btn.innerHTML = ICONS.download;
    }
  }
  setState('idle');

  function qualifies(el) {
    if (!el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < MIN_SIZE || r.height < MIN_SIZE) return false;
    if (el.tagName === 'IMG' && !/pinimg\.com/.test(el.currentSrc || el.src || '')) return false;
    return true;
  }

  const area = (el) => {
    const r = el.getBoundingClientRect();
    return r.width * r.height;
  };

  function mediaIn(host) {
    const list = [...host.querySelectorAll('video, img')].filter(qualifies);
    if (!list.length) return null;
    return list.find((e) => e.tagName === 'VIDEO') || list.sort((a, b) => area(b) - area(a))[0];
  }

  function mediaAt(x, y) {
    const els = document.elementsFromPoint(x, y);
    for (const el of els) {
      if (el === btn) return 'self';
      if ((el.tagName === 'IMG' || el.tagName === 'VIDEO') && qualifies(el)) return el;
    }
    // overlay Pinterest bisa menutupi gambar: cari media di dalam kartu pin
    for (const el of els.slice(0, 6)) {
      const host = el.closest ? el.closest(CARD_SEL) : null;
      if (host) {
        const m = mediaIn(host);
        if (m) return m;
      }
    }
    return null;
  }

  function place(media) {
    const r = media.getBoundingClientRect();
    const left = Math.max(r.left, 0);
    const right = Math.min(r.right, window.innerWidth);
    const top = Math.max(r.top, 0);
    const bottom = Math.min(r.bottom, window.innerHeight);
    if (right - left < 60 || bottom - top < 60) return false;
    const S = 36;
    const M = 12;
    let x, y;
    if (r.width >= 380) {
      x = right - M - S; // tampilan besar: kanan atas
      y = top + M;
    } else {
      x = left + M; // kartu di feed: kiri bawah
      y = bottom - M - S;
    }
    btn.style.left = x + 'px';
    btn.style.top = y + 'px';
    return true;
  }

  function hide() {
    if (lock) return;
    current = null;
    btn.classList.add('pdl-hidden');
  }

  function show(media) {
    current = media;
    if (!place(media)) return hide();
    btn.title = (media.tagName === 'VIDEO' ? 'Download video' : 'Download gambar') + ' (PinDL v' + VERSION + ')';
    btn.classList.remove('pdl-hidden');
  }

  function update() {
    if (lock) {
      if (current && current.isConnected) place(current);
      return;
    }
    const m = mediaAt(lastX, lastY);
    if (m === 'self') return;
    if (m) show(m);
    else hide();
  }

  function scheduleUpdate() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      ticking = false;
      update();
    });
  }

  document.addEventListener(
    'mousemove',
    (e) => {
      lastX = e.clientX;
      lastY = e.clientY;
      scheduleUpdate();
    },
    { passive: true, capture: true }
  );
  window.addEventListener('scroll', scheduleUpdate, { passive: true, capture: true });
  window.addEventListener('resize', scheduleUpdate);
  document.documentElement.addEventListener('mouseleave', () => hide());

  async function onDownload() {
    const media = current;
    if (!media || lock) return;
    lock = true;
    setState('busy');
    try {
      const job = await resolveMedia(media);
      let ok = false;
      let lastError = '';
      if (job.candidates.length) {
        const res = await chrome.runtime.sendMessage({
          type: 'PDL_DOWNLOAD',
          kind: job.kind,
          candidates: job.candidates,
          id: job.id
        });
        ok = !!(res && res.ok);
        if (!ok) lastError = (res && res.error) || '';
      }
      if (!ok) {
        if (job.kind === 'video' && job.hls.length) {
          toast('Mengunduh video (HLS)…');
          await downloadHls(job.hls, job.id);
        } else {
          throw new Error(lastError || 'Gagal mengunduh');
        }
      }
      setState('done');
      toast(job.kind === 'video' ? 'Video mulai diunduh' : 'Gambar mulai diunduh');
    } catch (err) {
      console.warn('[PinDL]', err);
      setState('error');
      toast((err && err.message) || 'Gagal mengunduh', true);
    }
    setTimeout(() => {
      lock = false;
      setState('idle');
      scheduleUpdate();
    }, 1500);
  }

  // Ambil event tombol di level window (capture) agar tidak sampai ke handler Pinterest
  const isBtn = (e) => e.target instanceof Element && !!e.target.closest('.pdl-btn');
  ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'touchstart', 'touchend', 'dblclick', 'auxclick'].forEach((type) =>
    window.addEventListener(
      type,
      (e) => {
        if (!isBtn(e)) return;
        e.stopImmediatePropagation();
        e.stopPropagation();
      },
      true
    )
  );
  window.addEventListener(
    'click',
    (e) => {
      if (!isBtn(e)) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      e.stopPropagation();
      onDownload();
    },
    true
  );
})();
